﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WebAPIProddet.Models
{
    public partial class Student
    {
        public Student()
        {
            Coursedetail = new HashSet<Coursedetail>();
        }

        public int Strno { get; set; }
        public string Stname { get; set; }
        public decimal? Feeamt { get; set; }
        public string Stemailid { get; set; }

        public virtual ICollection<Coursedetail> Coursedetail { get; set; }
    }
}
