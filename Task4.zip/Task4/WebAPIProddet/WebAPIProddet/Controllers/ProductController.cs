﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebAPIProddet.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebAPIProddet.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        // GET: api/<ProductController>
        [HttpGet]
        public IEnumerable<ProddDet> Get()
        {
            testdb1Context cnt = new testdb1Context();
            return cnt.ProddDet;
        }

        // GET api/<ProductController>/5
        [HttpGet("{id}")]
        public IEnumerable<ProddDet> Get(int id)
        {
            testdb1Context cnt = new testdb1Context();
            var sql = from i in cnt.ProddDet where i.Pcode == id select i;
            return sql;
        }

        // POST api/<ProductController>
        [HttpPost]
        public void Post([FromBody] ProddDet value)
        {
            testdb1Context cnt = new testdb1Context();
            cnt.ProddDet.Add(value);
            cnt.SaveChanges();
        }

        // PUT api/<ProductController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] ProddDet value)
        {
            testdb1Context cnt = new testdb1Context();
            var det = cnt.ProddDet.Find(id);
            if (det != null)
            {
                det.Pname = value.Pname;
                det.Unitprice = value.Unitprice;
                det.Category = value.Category;
                det.Pdesc = value.Pdesc;
                det.Stockinhand = value.Stockinhand;
                cnt.SaveChanges();
            }
        }

        // DELETE api/<ProductController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            testdb1Context cnt = new testdb1Context();
            var obj = cnt.ProddDet.Find(id);
            cnt.ProddDet.Remove(obj);
            cnt.SaveChanges();
        }
    }
}
