﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WebAPIReg.Models
{
    public partial class testdb1Context : DbContext
    {
        public testdb1Context()
        {
        }

        public testdb1Context(DbContextOptions<testdb1Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Accdet> Accdet { get; set; }
        public virtual DbSet<Automem> Automem { get; set; }
        public virtual DbSet<Category> Category { get; set; }
        public virtual DbSet<Categorynew> Categorynew { get; set; }
        public virtual DbSet<Coursedet> Coursedet { get; set; }
        public virtual DbSet<Coursedetail> Coursedetail { get; set; }
        public virtual DbSet<Dept> Dept { get; set; }
        public virtual DbSet<Difperson> Difperson { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Marks> Marks { get; set; }
        public virtual DbSet<Member> Member { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<ProddDet> ProddDet { get; set; }
        public virtual DbSet<Product> Product { get; set; }
        public virtual DbSet<Registration> Registration { get; set; }
        public virtual DbSet<Staffdet> Staffdet { get; set; }
        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<Studentdet> Studentdet { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=SHREDDER\\SQLEXPRESS;Initial Catalog=testdb1;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Accdet>(entity =>
            {
                entity.HasKey(e => new { e.Accno, e.Regno })
                    .HasName("PK__accdet__B5F6313C9DD87147");

                entity.ToTable("accdet");

                entity.Property(e => e.Accno).HasColumnName("accno");

                entity.Property(e => e.Regno).HasColumnName("regno");

                entity.Property(e => e.Ahname)
                    .HasColumnName("ahname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Damt)
                    .HasColumnName("damt")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<Automem>(entity =>
            {
                entity.HasKey(e => e.Mid)
                    .HasName("PK__automem__DF5032EC115F7EE8");

                entity.ToTable("automem");

                entity.Property(e => e.Mid).HasColumnName("mid");

                entity.Property(e => e.Mname)
                    .HasColumnName("mname")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Category>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("category");

                entity.HasIndex(e => e.Cid)
                    .HasName("UQ__category__D837D05E46DC4701")
                    .IsUnique();

                entity.Property(e => e.Cdesc)
                    .HasColumnName("cdesc")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Cid).HasColumnName("cid");

                entity.Property(e => e.Cname)
                    .HasColumnName("cname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Categorynew>(entity =>
            {
                entity.HasKey(e => e.Cid);

                entity.ToTable("categorynew");

                entity.Property(e => e.Cid)
                    .HasColumnName("cid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Cname)
                    .HasColumnName("cname")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Coursedet>(entity =>
            {
                entity.HasKey(e => e.Cid)
                    .HasName("PK__coursede__D837D05F070C3F0F");

                entity.ToTable("coursedet");

                entity.Property(e => e.Cid).HasColumnName("cid");

                entity.Property(e => e.Cduration)
                    .HasColumnName("cduration")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Cfee)
                    .HasColumnName("cfee")
                    .HasColumnType("money");

                entity.Property(e => e.Cname)
                    .HasColumnName("cname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Coursedetail>(entity =>
            {
                entity.HasKey(e => e.Cid);

                entity.ToTable("coursedetail");

                entity.Property(e => e.Cid)
                    .HasColumnName("cid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Cdurat).HasColumnName("cdurat");

                entity.Property(e => e.Cfee)
                    .HasColumnName("cfee")
                    .HasColumnType("money");

                entity.Property(e => e.Cname)
                    .HasColumnName("cname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Strno).HasColumnName("strno");

                entity.HasOne(d => d.StrnoNavigation)
                    .WithMany(p => p.Coursedetail)
                    .HasForeignKey(d => d.Strno)
                    .HasConstraintName("FK_coursedetail_coursedetail");
            });

            modelBuilder.Entity<Dept>(entity =>
            {
                entity.HasKey(e => e.Did)
                    .HasName("PK__dept__D877D216FA1B07AD");

                entity.ToTable("dept");

                entity.Property(e => e.Did).HasColumnName("did");

                entity.Property(e => e.Dloc)
                    .HasColumnName("dloc")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Dname)
                    .HasColumnName("dname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Difperson>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__difperso__DD37D91A2EF22619");

                entity.ToTable("difperson");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.Pname)
                    .HasColumnName("pname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.Eid)
                    .HasName("PK__employee__D9509F6D8ECA226F");

                entity.ToTable("employee");

                entity.Property(e => e.Eid)
                    .HasColumnName("eid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Did).HasColumnName("did");

                entity.Property(e => e.Edesig)
                    .HasColumnName("edesig")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ename)
                    .HasColumnName("ename")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Esal)
                    .HasColumnName("esal")
                    .HasColumnType("money");

                entity.Property(e => e.ReportingTo).HasColumnName("reporting_to");

                entity.HasOne(d => d.D)
                    .WithMany(p => p.Employee)
                    .HasForeignKey(d => d.Did)
                    .HasConstraintName("FK__employee__did__403A8C7D");
            });

            modelBuilder.Entity<Marks>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("marks");

                entity.Property(e => e.Marks1).HasColumnName("marks");

                entity.Property(e => e.Strno).HasColumnName("strno");
            });

            modelBuilder.Entity<Member>(entity =>
            {
                entity.HasKey(e => e.Mid)
                    .HasName("PK__member__DF5032EC625CAF55");

                entity.ToTable("member");

                entity.Property(e => e.Mid)
                    .HasColumnName("mid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Mname)
                    .HasColumnName("mname")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__person__DD37D91AEE691038");

                entity.ToTable("person");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.Gender)
                    .HasColumnName("gender")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Pname)
                    .HasColumnName("pname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProddDet>(entity =>
            {
                entity.HasKey(e => e.Pcode)
                    .HasName("PK__ProddDet__9F96D7D9331D1C04");

                entity.Property(e => e.Pcode).ValueGeneratedNever();

                entity.Property(e => e.Category)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pdesc)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Pname)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Unitprice).HasColumnType("money");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.Pid);

                entity.ToTable("product");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Cid).HasColumnName("cid");

                entity.Property(e => e.Pdesc)
                    .HasColumnName("pdesc")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Pname)
                    .HasColumnName("pname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pprice)
                    .HasColumnName("pprice")
                    .HasColumnType("money");

                entity.HasOne(d => d.C)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.Cid)
                    .HasConstraintName("FK_product_product");
            });

            modelBuilder.Entity<Registration>(entity =>
            {
                entity.HasKey(e => e.Rid)
                    .HasName("PK__Registra__C2B7EDE894818838");

                entity.Property(e => e.Rid)
                    .HasColumnName("rid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Contactno).HasColumnName("contactno");

                entity.Property(e => e.Experience)
                    .HasColumnName("experience")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Fname)
                    .HasColumnName("fname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Mailid)
                    .HasColumnName("mailid")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Skillset)
                    .HasColumnName("skillset")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Staffdet>(entity =>
            {
                entity.HasKey(e => e.Stid)
                    .HasName("PK__staffdet__312D1FC7A741AF85");

                entity.ToTable("staffdet");

                entity.Property(e => e.Stid)
                    .HasColumnName("stid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Scontactno).HasColumnName("scontactno");

                entity.Property(e => e.Smailid)
                    .HasColumnName("smailid")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Sname)
                    .HasColumnName("sname")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasKey(e => e.Strno)
                    .HasName("PK__student__ADB6E005AA693B83");

                entity.ToTable("student");

                entity.Property(e => e.Strno)
                    .HasColumnName("strno")
                    .ValueGeneratedNever();

                entity.Property(e => e.Feeamt)
                    .HasColumnName("feeamt")
                    .HasColumnType("money");

                entity.Property(e => e.Stemailid)
                    .HasColumnName("stemailid")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Stname)
                    .HasColumnName("stname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Studentdet>(entity =>
            {
                entity.HasKey(e => e.Sid);

                entity.ToTable("studentdet");

                entity.Property(e => e.Sid)
                    .HasColumnName("sid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Cid).HasColumnName("cid");

                entity.Property(e => e.Sedu)
                    .HasColumnName("sedu")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Semailid)
                    .HasColumnName("semailid")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Sname)
                    .HasColumnName("sname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.C)
                    .WithMany(p => p.Studentdet)
                    .HasForeignKey(d => d.Cid)
                    .HasConstraintName("FK_studentdet_coursedet");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
