﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebAPIReg.Models;
using WebAPIReg.Repository;

namespace WebAPIReg.Repository
{
    public class RegRepo:IReg
    {
        private testdb1Context _cnt;

        public RegRepo(testdb1Context cnt)//Dependency Inj
        {
            _cnt = cnt;
        }
        public async Task DeleteReg(int rid)
        {
            var obj = await _cnt.Registration.FindAsync(rid);
            _cnt.Registration.Remove(obj);
            await _cnt.SaveChangesAsync();
        }

        public async Task<IEnumerable<Registration>> GetAllReg()
        {
            return await _cnt.Registration.Select(i => i).ToListAsync();
        }

        public async Task<Registration> GetReg(int rid)
        {
            return await _cnt.Registration.FindAsync(rid);
        }

        public async Task<Registration> InsertReg(Registration Robj)
        {
            _cnt.Registration.Add(Robj);
            await _cnt.SaveChangesAsync();
            return Robj;
        }

        public async Task UpdateReg(Registration Robj)
        {
            _cnt.Entry(Robj).State = EntityState.Modified;
            await _cnt.SaveChangesAsync();
        }
    }
}
