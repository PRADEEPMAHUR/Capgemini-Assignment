﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebAPIReg.Models;

namespace WebAPIReg.Repository
{
    public interface IReg
    {
        Task<IEnumerable<Registration>> GetAllReg();
        Task<Registration> GetReg(int rid);
        Task<Registration> InsertReg(Registration Robj);
        Task UpdateReg(Registration Robj);
        Task DeleteReg(int rid);
    }
}
